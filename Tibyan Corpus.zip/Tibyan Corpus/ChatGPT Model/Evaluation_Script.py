from bert_score import score

# Function to calculate BERTScore
def calculate_bert_score(ref_texts, gen_texts):
    P, R, F1 = score(gen_texts, ref_texts, lang='ar', verbose=True)
    return P, R, F1

# File paths
ref_file_path = 'correct.txt'
gen_file_path = 'incorrect.txt'

# Your read_sentences_from_file function directly in the script
def read_sentences_from_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        sentences = [line.strip() for line in file]
    return sentences

# Read reference and generated sentences from files
reference_sentences = read_sentences_from_file(ref_file_path)
generated_sentences = read_sentences_from_file(gen_file_path)

# Calculate and print BERTScore
precision, recall, f1 = calculate_bert_score(reference_sentences, generated_sentences)
print(f"Precision: {precision.mean().item()}")
print(f"Recall: {recall.mean().item()}")
print(f"F1 Score: {f1.mean().item()}")
